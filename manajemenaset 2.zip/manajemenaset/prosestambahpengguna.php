<?php 
include "koneksi.php";

//$id=$_POST['id'];
$username=$_POST['username'];
$password=md5($_POST['password']);
$role=$_POST['role'];



$sql1 = "INSERT into user (username,password,role)values ('$username','$password','$role')";
var_dump($sql1);
$eksekusi1=mysqli_query($db, $sql1);
//$idsoalnya=mysqli_insert_id($db);


if ($eksekusi1) {
	
	?>
	<script type="text/javascript">
		alert('Data Berhasil ditambah');
		window.location="datapengguna.php";
	</script>
<?php 
}
 ?>