<?php 
include "koneksi.php";

$kode_aset=$_POST['kode_aset'];
$nama_aset=$_POST['nama_aset'];



$sql1 = "INSERT into tb_jenis_aset (kode_jenis, nama_jenis, jumlah) values ('$kode_aset', '$nama_aset', '0')";
$eksekusi1=mysqli_query($db, $sql1);
//$idsoalnya=mysqli_insert_id($db);


if ($eksekusi1) {
	
	?>
	<script type="text/javascript">
		alert('Data Berhasil disimpan');
		window.location="dataaset.php";
	</script>
<?php 
}
 ?>