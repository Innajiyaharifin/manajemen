<?php 
session_start();
if (empty($_SESSION['pengguna'])) {
    include "login.php";
}
else{
    $username = $_SESSION['pengguna'];



 ?>
<html lang="en" xmlns="http://www.w3.org/1999/html">
<head>
    <link rel="icon" type="image/png" href="images/DB_16х16.png">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="A front-end template that helps you build fast, modern mobile web apps.">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sistem Informasi Manajemen Penyusutan Aset</title>

    <!-- Add to homescreen for Chrome on Android -->
    <meta name="mobile-web-app-capable" content="yes">


    <!-- Add to homescreen for Safari on iOS -->
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Material Design Lite">


    <!-- Tile icon for Win8 (144x144 + tile color) -->
    <meta name="msapplication-TileImage" content="images/touch/ms-touch-icon-144x144-precomposed.png">
    <meta name="msapplication-TileColor" content="#3372DF">

    <!-- SEO: If your mobile URL is different from the desktop URL, add a canonical link to the desktop page https://developers.google.com/webmasters/smartphone-sites/feature-phones -->
    <!--
    <link rel="canonical" href="http://www.example.com/">
    -->

    <link href='https://fonts.googleapis.com/css?family=Roboto:400,500,300,100,700,900' rel='stylesheet'
          type='text/css'>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!-- inject:css -->
    <link rel="stylesheet" href="css/lib/getmdl-select.min.css">
    <link rel="stylesheet" href="css/lib/nv.d3.min.css">
    <link rel="stylesheet" href="css/application.min.css">
    <!-- endinject -->

</head>
<body>
<div class="mdl-layout mdl-js-layout mdl-layout--fixed-drawer mdl-layout--fixed-header is-small-screen">
    <?php 
                    include "koneksi.php";
                    $sql = "SELECT*FROM user where username='$username'";
                    $baca = mysqli_query($db, $sql);
                    $data = mysqli_fetch_array($baca);
                    $role = $data['role'];
                    if ($role == 1) {
                        include 'navbarsekretariat.php';
                    }
                    else if ($role == 2) {
                        include 'navbarpembina.php';
                    }
                    else if ($role == 3){
                        include 'navbaradmin.php';
                    }
                    else{
                         include 'navbarsekolah.php';

                    }




                 ?>
          
    <main class="mdl-layout__content">

        <div class="mdl-grid mdl-grid--no-spacing dashboard">

            <div class="mdl-grid mdl-cell mdl-cell--9-col-desktop mdl-cell--12-col-tablet mdl-cell--4-col-phone mdl-cell--top">
        <main class="mdl-layout__content mdl-color--grey-100">
            <div class="mdl-card mdl-shadow--2dp employer-form" action="#">
                <div class="mdl-card__title">
                    <h2>Form Tambah Aset</h2>
                </div>

                <div class="mdl-card__supporting-text">
                      <?php 

                      $id_jenis = $_GET['id'];
                                             

                                                    
                                                 ?>
                    <form action="prosestambahaset.php" method="POST" class="form">
                        <div class="form__article">

                            <div class="mdl-grid">

                                <input type="hidden" name="id_jenis" value="<?php echo $id_jenis?>">
                                <div class="mdl-cell mdl-cell--6-col mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                                    <input class="mdl-textfield__input" type="date" id="firstName" name="tanggal"/>
                                    <label class="mdl-textfield__label" for="firstName">Tanggal Pembelian</label>
                                </div>
                                <div class="mdl-cell mdl-cell--6-col mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                                    <input class="mdl-textfield__input" type="text" id="firstName" name="nama_vendor"/>
                                    <label class="mdl-textfield__label" for="firstName">Nama Vendor</label>
                                </div>
                              <div class="mdl-cell mdl-cell--6-col mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                                    <input class="mdl-textfield__input" type="text" id="firstName" name="kode_aset"/>
                                    <label class="mdl-textfield__label" for="firstName">Kode Aset</label>
                                </div>


                                <div class="mdl-cell mdl-cell--6-col mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                                    <input class="mdl-textfield__input" type="text" id="secondName"  name="nama_aset"/>
                                    <label class="mdl-textfield__label" for="secondName">Nama Aset</label>
                                </div>
                                <div class="mdl-cell mdl-cell--6-col mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                                    <input class="mdl-textfield__input" type="text" id="firstName" name="tahun_perolehan"/>
                                    <label class="mdl-textfield__label" for="firstName">Tahun Perolehan</label>
                                </div>

                                <div class="mdl-cell mdl-cell--6-col mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                                    <input class="mdl-textfield__input" type="text" id="secondName"  name="harga_perolehan"/>
                                    <label class="mdl-textfield__label" for="secondName">Harga Perolehan</label>
                                </div> 
                                <div class="mdl-cell mdl-cell--6-col mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                                    <input class="mdl-textfield__input" type="text" id="firstName" name="nilai_residu"/>
                                    <label class="mdl-textfield__label" for="firstName">Nilai Residu</label>
                                </div>

                                <div class="mdl-cell mdl-cell--6-col mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                                    <input class="mdl-textfield__input" type="text" id="secondName"  name="umur_ekonomis"/>
                                    <label class="mdl-textfield__label" for="secondName">Umur Ekonomis</label>
                                </div> 
                                <div class="mdl-cell mdl-cell--6-col mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                                    <input class="mdl-textfield__input" type="text" id="firstName" name="lokasi"/>
                                    <label class="mdl-textfield__label" for="firstName">Lokasi</label>
                                </div>

                                <div class="mdl-cell mdl-cell--6-col mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                                    <input class="mdl-textfield__input" type="text" id="secondName"  name="jumlah"/>
                                    <label class="mdl-textfield__label" for="secondName">Jumlah</label>
                                </div>
                            </div>

                           
                        <div class="form__action">
                           
                            <button  class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored" type="submit">
                                SIMPAN
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </main>
    </div>

            </div>
        </div>

    </main>

</div>

<!-- inject:js -->
<script src="js/d3.min.js"></script>
<script src="js/getmdl-select.min.js"></script>
<script src="js/material.min.js"></script>
<script src="js/nv.d3.min.js"></script>
<script src="js/layout/layout.min.js"></script>
<script src="js/scroll/scroll.min.js"></script>
<script src="js/widgets/charts/discreteBarChart.min.js"></script>
<script src="js/widgets/charts/linePlusBarChart.min.js"></script>
<script src="js/widgets/charts/stackedBarChart.min.js"></script>
<script src="js/widgets/employer-form/employer-form.min.js"></script>
<script src="js/widgets/line-chart/line-charts-nvd3.min.js"></script>
<script src="js/widgets/map/maps.min.js"></script>
<script src="js/widgets/pie-chart/pie-charts-nvd3.min.js"></script>
<script src="js/widgets/table/table.min.js"></script>
<script src="js/widgets/todo/todo.min.js"></script>
<!-- endinject -->

</body>
</html>
<?php } ?>