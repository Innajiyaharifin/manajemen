<?php 

include "koneksi.php";
$user = $_POST['user'];
$pass = md5($_POST['password']);


$sql = "SELECT * FROM user where username ='$user'AND password='$pass'";
$baca = mysqli_query($db, $sql);
//$itung = mysqli_num_rows($baca);
$data = mysqli_fetch_array($baca);
//var_dump($sql);
//var_dump($data);

if ($data['username'] != $user) {
	?>
	<script type="text/javascript">
			alert("Username salah");
			window.location="login.php";
		</script>

<?php 
	# code...
}
else if($data['password'] != $pass)
//if ($itung>0) 
{
	?>
		<script type="text/javascript">
			alert("Password Salah ");
			window.location="login.php";
		</script>

	<?php
}
else{
	session_start();
	$_SESSION['pengguna']=$data['username'];	

	?>
		<script type="text/javascript">
					alert("Berhasil Masuk Ke Sistem");
					window.location="index.php";
		</script>
<?php 
}


 ?>