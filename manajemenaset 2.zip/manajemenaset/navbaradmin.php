 <header class="mdl-layout__header">
        <div class="mdl-layout__header-row">
            <div class="mdl-layout-spacer"></div>
            <!-- Search-->
           
            <!-- Notifications dropdown-->

            <div class="avatar-dropdown" id="icon">
                <span><?php echo $username?></span>
                <img src="images/logo.jpg">
            </div>
        </div>
    </header>

    <div class="mdl-layout__drawer">
        <header>Manajemen Aset BPI</header>
        <div class="scroll__wrapper" id="scroll__wrapper">
            <div class="scroller" id="scroller">
                <div class="scroll__container" id="scroll__container">
                    <nav class="mdl-navigation">
                       
                        
                       
                        <a class="mdl-navigation__link" href="datapengguna.php">
                            <i class="material-icons" role="presentation">person</i>
                            Data Pengguna
                        </a>
                       
                         <a class="mdl-navigation__link" href="logout.php">
                            <i class="material-icons" role="presentation">person</i>
                            Logout
                        </a>
                        <div class="mdl-layout-spacer"></div>
                        <hr>
                        <a class="mdl-navigation__link" href="">
                            <i class="material-icons" role="presentation">link</i>
                            By Asadullah
                        </a>
                    </nav>
                </div>
            </div>
            <div class='scroller__bar' id="scroller__bar"></div>
        </div>
    </div>
