<?php 
include "koneksi.php";

$id=$_GET['id'];



$sql1 = "UPDATE tb_nama_aset set status = 'Diterima'  WHERE id='$id'";
$eksekusi1=mysqli_query($db, $sql1);
//$idsoalnya=mysqli_insert_id($db);



$a="SELECT * FROM tb_nama_aset where id='$id'";
$aa=mysqli_query($db, $a);
$aaa=mysqli_fetch_array($aa);
$jumlah = $aaa['jumlah'];
$id_jenis_aset = $aaa['id_jenis_aset'];




$sql2="SELECT jumlah FROM tb_jenis_aset where id='$id_jenis_aset'";
$eksekusi2=mysqli_query($db, $sql2);
$data=mysqli_fetch_array($eksekusi2);
$jumlahaset = $data['jumlah'];

$jumlahbaru = $jumlahaset+$jumlah;
$sql3="UPDATE tb_jenis_aset set jumlah ='$jumlahbaru' where id='$id_jenis_aset'";
$eksekusi2=mysqli_query($db, $sql3);

if ($eksekusi1) {
	
	?>
	<script type="text/javascript">
		alert('Data Berhasil diubah');
		window.location="dataaset.php";
	</script>
<?php 
}
 ?>