 <header class="mdl-layout__header">
        <div class="mdl-layout__header-row">
            <div class="mdl-layout-spacer"></div>
            <!-- Search-->
           
            <!-- Notifications dropdown-->

            <div class="avatar-dropdown" id="icon">
                <span><?php echo $username?></span>

                <img src="images/logo.jpg">
            </div>
        </div>
    </header>

    <div class="mdl-layout__drawer">
        <header>Manajemen Aset BPI</header>
        <div class="scroll__wrapper" id="scroll__wrapper">
            <div class="scroller" id="scroller">
                <div class="scroll__container" id="scroll__container">
                    <nav class="mdl-navigation">
                       
                        
                        <a class="mdl-navigation__link" href="dataaset.php">
                            <i class="material-icons">developer_board</i>
                            Data Aset
                        </a>
                       <!-- <a class="mdl-navigation__link" href="forms.html">
                            <i class="material-icons" role="presentation">person</i>
                            Account
                        </a>-->
                        <a class="mdl-navigation__link" href="datapembelian.php">
                            <i class="material-icons" role="presentation">map</i>
                            Data Pembelian Aset
                        </a>
                        <a class="mdl-navigation__link" href="datapenjualan.php">
                            <i class="material-icons" role="presentation">map</i>
                            Data Penjualan Aset
                        </a>
                       <a class="mdl-navigation__link" href="datapeminjaman.php">
                            <i class="material-icons" role="presentation">map</i>
                            Data Peminjaman Aset
                        </a>
                        <a class="mdl-navigation__link" href="dataapenyusutanset.php">
                            <i class="material-icons" role="presentation">map</i>
                            Data Penyusutan Aset
                        </a>
                        <a class="mdl-navigation__link" href="dataapenghapusanset.php">
                            <i class="material-icons" role="presentation">map</i>
                            Data Penghapusan Aset
                        </a>
                         <a class="mdl-navigation__link" href="logout.php">
                            <i class="material-icons" role="presentation">person</i>
                            Logout
                        </a>
                        <div class="mdl-layout-spacer"></div>
                        <hr>
                        <a class="mdl-navigation__link" href="">
                            <i class="material-icons" role="presentation">link</i>
                            By Asadullah
                        </a>
                    </nav>
                </div>
            </div>
            <div class='scroller__bar' id="scroller__bar"></div>
        </div>
    </div>
