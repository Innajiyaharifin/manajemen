<?php 
include "koneksi.php";

$id=$_POST['id'];
$id_user=$_POST['id_user'];
$lama_pinjam=$_POST['lama_pinjam'];
$tanggal_pinjam=$_POST['tanggal_pinjam'];
$jumlah_pinjam=$_POST['jumlah_pinjam'];



$sql1 = "INSERT into tb_peminjaman (id_aset, tanggal_pinjam, lama_pinjam, jumlah_pinjam, status, id_user) values ('$id', '$tanggal_pinjam', '$lama_pinjam','$jumlah_pinjam','pengajuan','$id_user')";
$eksekusi1=mysqli_query($db, $sql1);
//var_dump($sql1);
//$idsoalnya=mysqli_insert_id($db);


if ($eksekusi1) {
	
	?>
	<script type="text/javascript">
		alert('Data Berhasil disimpan');
		window.location="datapeminjamansekolah.php";
	</script>
<?php 
}
 ?>