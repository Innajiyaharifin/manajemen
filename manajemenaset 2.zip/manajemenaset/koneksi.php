<?php 


$db=mysqli_connect("localhost","root","","manajemen_aset");
if (!$db) {
	echo "Gagal";
}



 ?>