<?php 
include "koneksi.php";

$id=$_GET['id'];



$sql1 = "UPDATE tb_nama_aset set status = 'Ditolak'  WHERE id='$id'";
$eksekusi1=mysqli_query($db, $sql1);
//$idsoalnya=mysqli_insert_id($db);



if ($eksekusi1) {
	
	?>
	<script type="text/javascript">
		alert('Data Berhasil diubah');
		window.location="dataaset.php";
	</script>
<?php 
}
 ?>