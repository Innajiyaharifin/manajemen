<?php 
include "koneksi.php";


$id_aset= $_POST['id'];
$harga=$_POST['harga_perolehan'];
$nilai_residu=$_POST['nilai_residu'];
$umur_ekonomis=$_POST['umur_ekonomis'];

$nilai_penyusutan = ($harga - $nilai_residu) / $umur_ekonomis;


$sql1 = "INSERT into tb_penyusutan (id_aset, nilai_penyusutan) values ('$id_aset', '$nilai_penyusutan')";
$eksekusi1=mysqli_query($db, $sql1);
//$idsoalnya=mysqli_insert_id($db);


if ($eksekusi1) {
	
	?>
	<script type="text/javascript">
		alert('Data Berhasil disimpan');
		window.location="dataapenyusutanset.php";
	</script>
<?php 
}
 ?>