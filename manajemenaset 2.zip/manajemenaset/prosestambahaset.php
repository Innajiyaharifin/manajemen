<?php 
 //$id =$data['id_nama_aset'];
include "koneksi.php";
$id_jenis_aset=$_POST['id_jenis'];
$tanggal =$_POST['tanggal'];
$nama_vendor =$_POST['nama_vendor'];
$nama =$_POST['nama_aset'];
$kode =$_POST['kode_aset'];
$tahun_perolehan =$_POST['tahun_perolehan'];
$harga_perolehan =$_POST['harga_perolehan'];
$nilai_residu =$_POST['nilai_residu'];
$umur_ekonomis =$_POST['umur_ekonomis'];
$lokasi =$_POST['lokasi'];
$jumlah =$_POST['jumlah']; 	
                                                    


$sql1 = "INSERT into tb_nama_aset (kode_aset, nama_aset, tahun_perolehan,harga_perolehan,nilai_residu,umur_ekonomis,lokasi,jumlah,id_jenis_aset,status, tanggal_pembelian,vendor) values('$kode', '$nama', '$tahun_perolehan', '$harga_perolehan', '$nilai_residu', '$umur_ekonomis', '$lokasi', '$jumlah', '$id_jenis_aset','diajukan','$tanggal','$nama_vendor')";
$eksekusi1=mysqli_query($db, $sql1);
//var_dump($sql1);
//$idsoalnya=mysqli_insert_id($db);

//$sql2="SELECT jumlah FROM tb_jenis_aset where id='$id_jenis_aset'";
//$eksekusi2=mysqli_query($db, $sql2);
//$data=mysqli_fetch_array($eksekusi2);
//$jumlahaset = $data['jumlah'];

//$jumlahbaru = $jumlahaset+$jumlah;
//$sql3="UPDATE tb_jenis_aset set jumlah ='$jumlahbaru' where id='$id_jenis_aset'";
//$eksekusi2=mysqli_query($db, $sql3);



if ($eksekusi1) {
	
	?>
	<script type="text/javascript">
		alert('Data Berhasil disimpan');
		window.location="dataaset.php";
	</script>
<?php 
}



 ?>