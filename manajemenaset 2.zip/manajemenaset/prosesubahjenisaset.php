<?php 
include "koneksi.php";

$id=$_POST['id'];
$kode_aset=$_POST['kode_aset'];
$nama_aset=$_POST['nama_aset'];
$jumlah_aset=$_POST['jumlah_aset'];



$sql1 = "UPDATE tb_jenis_aset set kode_jenis='$kode_aset', 
								nama_jenis='$nama_aset', 
								jumlah='$jumlah_aset'  WHERE id='$id'";
$eksekusi1=mysqli_query($db, $sql1);
//$idsoalnya=mysqli_insert_id($db);


if ($eksekusi1) {
	
	?>
	<script type="text/javascript">
		alert('Data Berhasil diubah');
		window.location="dataaset.php";
	</script>
<?php 
}
 ?>