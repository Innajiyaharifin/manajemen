<?php 
include "koneksi.php";

$id=$_POST['id'];
$nilai_penyusutan=$_POST['nilai_penyusutan'];
$kriteria_kerusakan=$_POST['kriteria_kerusakan'];
$lama_pakai=$_POST['lama_pakai'];
$nama_aset=$_POST['nama_aset'];




$c1=0.50*($kriteria_kerusakan/0.65);
$c2=0.35*($nilai_penyusutan/5000);
$c3=0.15*($lama_pakai/1825);

$nilaipenghapusan = $c1+$c2+$c3;

if ($nilaipenghapusan > 0.8) {
	$carahapus = "dimusnahkan";
}
else if ($nilaipenghapusan > 0.5) {
	$carahapus = "dilelang / dijual";
}
else if ($nilaipenghapusan > 0) {
	$carahapus = "disumbangkan";
}



$sql1 = "INSERT into tb_penghapusan (id_aset, nilai_penghapusan, hasil_penghapusan) values ('$id', '$nilaipenghapusan', '$carahapus')";
$eksekusi1=mysqli_query($db, $sql1);
//$idsoalnya=mysqli_insert_id($db);


if ($eksekusi1) {
	
	?>
	<script type="text/javascript">
		alert('Data Berhasil disimpan');
		window.location="datasolusihapus.php?id=<?php echo $id?>";
	</script>
<?php 
}
 ?>